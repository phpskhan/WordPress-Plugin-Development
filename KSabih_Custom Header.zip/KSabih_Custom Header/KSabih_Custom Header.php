<?php

/*
 * Plugin Name:       KSabih Custom Header
 * Plugin URI:        https://ksabih.com/
 * Description:       Custom Header Support.
 * Version:           1.0.0
 * Author:            Sabih Khan
 * Author URI:        https://ksabih.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ksabih_cwpp1
 */

$args = array (
    'default-image' => get_template_directory_uri().'/assets/img/lms_banner.png',
    'default-text-color' => '000',
    'width' => 1920,
    'height' => 400,
    'flex-width' => true,
    'flex-height' => true,

);

add_theme_support( 'custom-header', $args );