<?php
/*
 * Plugin Name:       Excerpt Length
 * Plugin URI:        https://ksabih.com/
 * Description:       Change Excerpt Length for the post.
 * Version:           1.0.0
 * Author:            Sabih Khan
 * Author URI:        https://ksabih.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ksabih_cwpp2
 */

function ksabih_cwpp2_like_filer( $words ){
    return 10;
}
add_action( 'excerpt_length', 'ksabih_cwpp2_like_filer' );
