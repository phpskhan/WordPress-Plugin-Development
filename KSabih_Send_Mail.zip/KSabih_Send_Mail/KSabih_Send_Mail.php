/*
 * Plugin Name:       Custom WP Features
 * Plugin URI:        https://ksabih.com/
 * Description:       Adding Features on the Website.
 * Version:           1.0.0
 * Author:            Sabih Khan
 * Author URI:        https://ksabih.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ksabih_cwpp1
 */

