<style>
    button {
        font-weight: bold;
        width: 50%;
        margin-left: 10px;
        position: absolute;
        background: rgb(231, 9, 76);
        padding: 10px 20px;
        margin: 10px;
        border: 1px solid #fff;
        border-radius: 5px;
        left: 0;

    }
    button:hover {
        color: rgb(231, 9, 76) !important;
        background: #fff;
        border: 1px solid #262626;
        border-radius: 5px;
    }

    a {
        color: #fff !important;
        text-decoration: none;
    }
    a:hover {
        color: rgb(231, 9, 76) !important;
    }
</style>

<?php
/*
 * Plugin Name:       Read More Button
 * Plugin URI:        https://ksabih.com/
 * Description:       Read more Button for Post Excerpt.
 * Version:           1.0.0
 * Author:            Sabih Khan
 * Author URI:        https://ksabih.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ksabih_cwpp2
 */

function ksabih_cwpp2_custom_excerpt_length( $length ) {
    return 19;
}
add_filter( 'excerpt_length', 'ksabih_cwpp2_custom_excerpt_length', 999 );

function ksabih_cwpp2_custom_excerpt_more( $more ){
    $more = '<a href="'.get_the_permalink().'"><button>Read More . . </button></a>';
    return $more;
}
add_action( 'excerpt_more', 'ksabih_cwpp2_custom_excerpt_more' );
